<?php

if(isset($_GET['folder']))
{
	$dir = $_GET['folder'];

	$files_fetch = scandir($dir);
  $files_fetch = array_diff(scandir($dir), array('.', '..'));

  function OnlyFolders($dir2, $curr)
  {
    $directories = array_filter(glob($dir2.'/*'), 'is_dir');
    echo "<option value='".$dir2."/".$curr."'>";
    echo $dir2;
    echo "</option>";
    foreach ($directories as $key => $value)
    {
      $subdirectories[] = array_filter(glob($value.'/*'), 'is_dir');
      // echo $value."<br>";
    }
    
    foreach ($directories as $key1 => $value1)
    {
      foreach ($subdirectories as $key2 => $value2)
      {
        if ($key1 == $key2)
        {
          echo "<option value='".$value1."/".$curr."'>";
          echo $value1;
          echo "</option>";
          foreach ($value2 as $key3 => $value3)
          {                                                        
            OnlyFolders($value3, $curr);
          }
        }
      }
    }                
  }

  		echo 
  		'
        <div class="modal fade" id="createFolder">
			    <div class="modal-dialog modal-dialog-centered">
			      <div class="modal-content">
			      
			        <!-- Modal Header -->
			        <div class="modal-header">
			          <h4 class="modal-title">Create New Folder</h4>
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			        </div>
			        
			        <!-- Modal body -->
			        <div class="modal-body">				          
			          <input type="hidden" class="form-control" id="source" value="'.$dir.'">
		            <div class="input-group mb-3">
						      <input type="text" class="form-control" id="folder" value="New Folder">
						      <div class="input-group-append">
						        <button type="button" onclick="createFolder( $('."'#source'".').val(), $('."'#folder'".').val(), event );" class="btn btn-success">Create Folder</button>
						      </div>
						    </div>         
			        </div>

			      </div>
			    </div>
			  </div>
      ';
      echo 
		  '
		    <div class="modal fade" id="uploadFiles">
		      <div class="modal-dialog modal-dialog-centered">
		        <div class="modal-content">
		        
		          <!-- Modal Header -->
		          <div class="modal-header">
		            <h4 class="modal-title">Upload Files</h4>
		            <button type="button" class="close" data-dismiss="modal">&times;</button>
		          </div>
		          
		          <!-- Modal body -->
		          <div class="modal-body">
		            <form method="POST" enctype="multipart/form-data" class="uploadFiles">
		              <input type="hidden" class="form-control" id="source" name="source" value="'.$dir.'">
		              <div class="input-group mb-3">
		                <input type="file" class="form-control" id="file" name="file[]" multiple accept=".jpg, .jpeg, .png, .pdf" required>
		                <div class="input-group-append">
		                  <input type="submit" class="btn btn-success submit_upload" value="Upload File">
		                </div>
		              </div>
		              <p class="text-danger">.PNG, .JPEG, .JPG, .PDF</p>
		            </form>
		          </div>
		          
		        </div>
		      </div>
		    </div>
		  ';
	  	echo '
    		<div class="table-responsive" style="height: 30rem">
              <table class="table align-middle table-nowrap table-hover mb-0">
                  <thead>
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Date modified</th>
                        <th>Type</th>
                        <th scope="col" colspan="2">Size</th>
                      </tr>
                    </thead>
                  <tbody>
	    ';
    	if(dirname($dir) != '.' && dirname($dir) != '..')
    	{
    		echo '
			        <tr>
			            <td colspan="5">
			              <a href="'.$dir.'" id="'.dirname($dir).'/" onclick="FetchFolder(this.id, event);" class="text-dark fw-medium fetch_folder">
			                <i class="fa fa-undo font-size-16 align-middle text-body mr-2"></i> 
			                Back
			              </a>
			            </td>
			        </tr>
			      ';
			}
	    foreach ($files_fetch as $key => $value)
	    {
	      	$path = $dir.$value;

	      	if(is_file($path))
    			{
	      		$filesize = filesize($path);
	      		// echo $path."<br>";
	      		if (pathinfo($path, PATHINFO_EXTENSION) == 'jpg' ||
	      			pathinfo($path, PATHINFO_EXTENSION) == 'jpeg' ||
	      			pathinfo($path, PATHINFO_EXTENSION) == 'png')
	      		{
	      			echo '			      
	                  <tr>
	                      <td>
	                      	<a href="'.$path.'"  id="'.dirname($path).'/" target="_blank" class="text-dark fw-medium">
	                      	<i class="fa fa-image font-size-16 align-middle text-primary mr-2"></i> 
	                      	'.$value.'
	                      	</a>
	                      </td>
	                      <td>'.date("Y-m-d", filemtime($path)).'</td>
	                      <td>Image File</td>
	                      <td>'.formatSizeUnits($filesize).'</td>
	                      <td>
	                          <div class="dropdown">
	                              <a class="font-size-16 text-muted" role="button" data-toggle="dropdown" aria-haspopup="true">
	                                  <i class="fa fa-ellipsis-h"></i>
	                              </a>
	                              
	                              <div class="dropdown-menu dropdown-menu-end">
	                                  <a class="dropdown-item" href="'.$path.'" target="_blank">Open</a>
	                                  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#copyModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Copy</a>
                          					<a class="dropdown-item" href="#" data-toggle="modal" data-target="#moveModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Move</a>
	                                  <a class="dropdown-item" href="'.$path.'" download>Download</a>
	                                  <a class="dropdown-item" href="'.$path.'">Share</a>
	                                  <a class="dropdown-item rename_img" href="#" data-toggle="modal" data-target="#RenameIMG_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Rename</a>
	                                  <div class="dropdown-divider"></div>
	                                  <a class="dropdown-item" href="#" id="'.$path.'" onclick="remove(this.id, '."'file'".', event);">Remove</a>
	                              </div>

	                              <div class="modal fade copyModal" id="copyModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Copy File</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
					                            <div class="modal-body">
					                              <input type="text" class="form-control" name="source" id="source_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.$path.'">
					                              <label>Select Path</label>
					                              <div class="input-group mb-3">
					                                ';                                              
					                                  echo "<select class='form-control' id='destination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."' name='destination'>";
					                                  OnlyFolders('../Documents', $value);
					                                  echo "</select>";
					                                echo '
					                                <div class="input-group-append">
					                                  <input type="button" class="btn btn-success submit_copy" value="Copy"
					                                  onclick="CopyFunction($('."'#source_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), $('."'#destination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val());">
					                                </div>
					                              </div>

					                            </div>
                                      
                                    </div>
                                  </div>
                                </div>

                                <div class="modal fade moveModal" id="moveModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Move File</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
					                            <div class="modal-body">
					                              <input type="text" class="form-control" name="source" id="msource_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.$path.'">
					                              <label>Select Path</label>
					                              <div class="input-group mb-3">
					                                ';                                              
					                                  echo "<select class='form-control' id='mdestination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."' name='destination'>";
					                                  OnlyFolders('../Documents', $value);
					                                  echo "</select>";
					                                echo '
					                                <div class="input-group-append">
					                                  <input type="button" class="btn btn-success submit_move" value="Move"
					                                  onclick="MoveFunction($('."'#msource_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), $('."'#mdestination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val());">
					                                </div>
					                              </div>

					                            </div>
                                      
                                    </div>
                                  </div>
                                </div>

	                              <div class="modal fade rename_img_modal" id="RenameIMG_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Rename File "'.$value.'"</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
                                      <div class="modal-body">
                                        <input type="text" class="form-control d-inline-block w-75" id="rename_img_file_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.pathinfo($path, PATHINFO_FILENAME).'" />.'.pathinfo($path, PATHINFO_EXTENSION).'
                                      </div>
                                      
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" id="'.pathinfo($path, PATHINFO_FILENAME).'.'.pathinfo($path, PATHINFO_EXTENSION).'" folder="'.$dir.'" extension=".'.pathinfo($path, PATHINFO_EXTENSION).'"
                                        onclick="RenameIMG($('."'#rename_img_file_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), this.id, $(this).attr('."'folder'".'), $(this).attr('."'extension'".'));">Rename</button>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>
	                          </div>
	                      </td>
	                  </tr>	                      
			      ';
	      		}
	      		elseif(pathinfo($path, PATHINFO_EXTENSION) == 'pdf')
	      		{
	      			echo '			      
	                  <tr>
	                      <td>
	                      <a href="'.$path.'" id="'.dirname($path).'/" target="_blank" class="text-dark fw-medium">
	                      	<i class="fa fa-file-archive-o font-size-16 align-middle text-danger mr-2"></i> 
	                      	'.$value.'
	                      	</a>
	                      </td>
	                      <td>'.date("Y-m-d", filemtime($path)).'</td>
	                      <td>PDF File</td>
	                      <td>'.formatSizeUnits($filesize).'</td>
	                      <td>
	                          <div class="dropdown">
	                              <a class="font-size-16 text-muted" role="button" data-toggle="dropdown" aria-haspopup="true">
	                                  <i class="fa fa-ellipsis-h"></i>
	                              </a>
	                              
	                              <div class="dropdown-menu dropdown-menu-end">
	                                  <a class="dropdown-item" href="'.$path.'" target="_blank">Open</a>
	                                  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#copyModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Copy</a>
                          					<a class="dropdown-item" href="#" data-toggle="modal" data-target="#moveModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Move</a>
	                                  <a class="dropdown-item" href="'.$path.'" download>Download</a>
	                                  <a class="dropdown-item" href="'.$path.'">Share</a>
	                                  <a class="dropdown-item rename_pdf" href="#" data-toggle="modal" data-target="#RenamePDF_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Rename</a>
	                                  <div class="dropdown-divider"></div>
	                                  <a class="dropdown-item" href="#" id="'.$path.'" onclick="remove(this.id, '."'file'".', event);">Remove</a>
	                              </div>

	                              <div class="modal fade copyModal" id="copyModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Copy File</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
					                            <div class="modal-body">
					                              <input type="text" class="form-control" name="source" id="source_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.$path.'">
					                              <label>Select Path</label>
					                              <div class="input-group mb-3">
					                                ';                                              
					                                  echo "<select class='form-control' id='destination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."' name='destination'>";
					                                  OnlyFolders('../Documents', $value);
					                                  echo "</select>";
					                                echo '
					                                <div class="input-group-append">
					                                  <input type="button" class="btn btn-success submit_copy" value="Copy"
					                                  onclick="CopyFunction($('."'#source_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), $('."'#destination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val());">
					                                </div>
					                              </div>

					                            </div>
                                      
                                    </div>
                                  </div>
                                </div>

                                <div class="modal fade moveModal" id="moveModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Move File</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
					                            <div class="modal-body">
					                              <input type="text" class="form-control" name="source" id="msource_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.$path.'">
					                              <label>Select Path</label>
					                              <div class="input-group mb-3">
					                                ';                                              
					                                  echo "<select class='form-control' id='mdestination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."' name='destination'>";
					                                  OnlyFolders('../Documents', $value);
					                                  echo "</select>";
					                                echo '
					                                <div class="input-group-append">
					                                  <input type="button" class="btn btn-success submit_move" value="Move"
					                                  onclick="MoveFunction($('."'#msource_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), $('."'#mdestination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val());">
					                                </div>
					                              </div>

					                            </div>
                                      
                                    </div>
                                  </div>
                                </div>

	                              <div class="modal fade rename_pdf_modal" id="RenamePDF_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Rename File "'.$value.'"</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
                                      <div class="modal-body">
                                        <input type="text" class="form-control d-inline-block w-75" id="rename_pdf_file_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.pathinfo($path, PATHINFO_FILENAME).'" />.pdf
                                      </div>
                                      
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" id="'.pathinfo($path, PATHINFO_FILENAME).'" folder="'.$dir.'"
                                        onclick="RenamePDF($('."'#rename_pdf_file_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), this.id, $(this).attr('."'folder'".'));">Rename</button>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>
	                          </div>
	                      </td>
	                  </tr>	                      
			      ';
	      		}
	      	}
      		elseif(is_dir($path))
      		{
			    	echo '			      
	                  <tr>
	                      <td>
	                      	<a href="'.$dir.'" id="'.$path.'/" onclick="FetchFolder(this.id, event);" class="text-dark fw-medium fetch_folder">
	                      	<i class="fa fa-folder font-size-16 align-middle text-warning mr-2"></i> 
	                      	'.$value.'
	                      	</a>
	                      </td>
	                      <td>'.date("Y-m-d", filemtime($path)).'</td>
	                      <td>File Folder</td>
	                      <td></td>
	                      <td>
	                          <div class="dropdown">
	                              <a class="font-size-16 text-muted" role="button" data-toggle="dropdown" aria-haspopup="true">
	                                  <i class="fa fa-ellipsis-h"></i>
	                              </a>
	                              
	                              <div class="dropdown-menu dropdown-menu-end">
	                                  <a class="dropdown-item" href="#" id="'.$path.'/" onclick="FetchFolder(this.id, event);">Open</a>
	                                  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#copyModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Copy</a>
                        						<a class="dropdown-item" href="#" data-toggle="modal" data-target="#moveModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Move</a>
	                                  <a class="dropdown-item rename_folder" href="#" data-toggle="modal" data-target="#RenameFOLDER_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">Rename</a>
	                                  <div class="dropdown-divider"></div>
	                                  <a class="dropdown-item" href="#" id="'.$path.'" onclick="remove(this.id, '."'folder'".', event);">Remove</a>
	                              </div>

	                              <div class="modal fade copyModal" id="copyModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Copy Folder</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
					                            <div class="modal-body">
					                              <input type="text" class="form-control" name="source" id="source_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.$path.'">
					                              <label>Select Path</label>
					                              <div class="input-group mb-3">
					                                ';                                              
					                                  echo "<select class='form-control' id='destination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."' name='destination'>";
					                                  OnlyFolders('../Documents', $value);
					                                  echo "</select>";
					                                echo '
					                                <div class="input-group-append">
					                                  <input type="button" class="btn btn-success submit_copy" value="Copy"
					                                  onclick="CopyFunction($('."'#source_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), $('."'#destination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val());">
					                                </div>
					                              </div>

					                            </div>
                                      
                                    </div>
                                  </div>
                                </div>

                                <div class="modal fade moveModal" id="moveModal_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Move Folder</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
					                            <div class="modal-body">
					                              <input type="text" class="form-control" name="source" id="msource_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.$path.'">
					                              <label>Select Path</label>
					                              <div class="input-group mb-3">
					                                ';                                              
					                                  echo "<select class='form-control' id='mdestination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."' name='destination'>";
					                                  OnlyFolders('../Documents', $value);
					                                  echo "</select>";
					                                echo '
					                                <div class="input-group-append">
					                                  <input type="button" class="btn btn-success submit_move" value="Move"
					                                  onclick="MoveFunction($('."'#msource_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), $('."'#mdestination_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val());">
					                                </div>
					                              </div>

					                            </div>
                                      
                                    </div>
                                  </div>
                                </div>

	                              <div class="modal fade rename_folder_modal" id="RenameFOLDER_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'">
                                  <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                    
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                        <h4 class="modal-title">Rename Folder "'.$value.'"</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      
                                      <!-- Modal body -->
                                      <div class="modal-body">
                                        <input type="text" class="form-control d-inline-block w-75" id="rename_folder_value_'.str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME)).'" value="'.pathinfo($path, PATHINFO_FILENAME).'" />
                                      </div>
                                      
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" id="'.pathinfo($path, PATHINFO_FILENAME).'" folder="'.$dir.'"
                                        onclick="RenameFOLDER($('."'#rename_folder_value_".str_replace(array(' ', '(', ')', '-'), array('_', '', '', ''), pathinfo($path, PATHINFO_FILENAME))."'".').val(), this.id, $(this).attr('."'folder'".'));">Rename</button>
                                      </div>
                                      
                                    </div>
                                  </div>
                                </div>
	                          </div>
	                      </td>
	                  </tr>	                      
			      ';
		  		}
	    }
	    echo '
	    		</tbody>
          </table>
      </div>
	    ';
}

function formatSizeUnits($bytes)
{
  if ($bytes >= 1073741824)
  {
      $bytes = number_format($bytes / 1073741824, 2) . ' GB';
  }
  elseif ($bytes >= 1048576)
  {
      $bytes = number_format($bytes / 1048576, 2) . ' MB';
  }
  elseif ($bytes >= 1024)
  {
      $bytes = number_format($bytes / 1024, 2) . ' KB';
  }
  elseif ($bytes > 1)
  {
      $bytes = $bytes . ' bytes';
  }
  elseif ($bytes == 1)
  {
      $bytes = $bytes . ' byte';
  }
  else
  {
      $bytes = '0 byte';
  }

  return $bytes;
}
?>